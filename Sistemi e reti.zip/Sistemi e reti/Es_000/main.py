from utime import sleep

while True:
  print("Hello World! \n")
  print("Ciao Mondo! \n")
  sleep(1)